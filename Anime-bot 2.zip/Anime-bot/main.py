import os
import logging
from pyrogram import Client, filters
import asyncio

# Logging setup
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Direct values instead of getenv
BOT_TOKEN = "7017121792:AAGZ0hmyzeshCaxSbme-NPiyHge0CtqczoE"  # Replace with your actual bot token
API_ID = 25709025  # Replace with your actual API ID
API_HASH = "b95bc74de48d8916c4edd615dde26280"  # Replace with your actual API hash
ADMIN_ID = 6038098264 # Replace with your actual admin ID

# Pyrogram Client Setup for Bot
bot = Client("anime_bot", api_id=API_ID, api_hash=API_HASH, bot_token=BOT_TOKEN)

# Pyrogram Client Setup for User
user = Client("user_session", api_id=API_ID, api_hash=API_HASH)

# Welcome Message
@bot.on_message(filters.command("start"))
async def start(client, message):
    await message.reply_text("🎉 Welcome to the Anime Bot!\nSimply type the name of the anime you want to search for.")

CHANNEL_ID = "@animesaga07"  # Channel ID yahan daalo

# Direct Search Functionality
@bot.on_message(filters.text & ~filters.command(["start", "admin", "broadcast"]))
async def direct_search(client, message):
    anime_name = message.text
    logger.info(f"Search request received from {message.from_user.id} for: {anime_name}")

    # Send searching message
    search_msg = await message.reply_text(f"Searching for '{anime_name}'... Please wait")

    await asyncio.sleep(1)  # Small delay to make it look more natural

    results = []

    try:
        # Start user session
        await user.start()
        logger.info("User session started successfully.")

        # Search messages in the channel
        async for msg in user.search_messages(CHANNEL_ID, query=anime_name, limit=5):  # Limit set karo
            logger.info(f"Found message: {msg.text or msg.caption}")
            if msg.text or msg.caption:
                result_text = msg.text or msg.caption
                # Format the message as per your screenshot
                if "Ep" in result_text and "Quality" in result_text:
                    formatted_text = f"**{result_text.splitlines()[0]}**\n"
                    for line in result_text.splitlines()[1:]:
                        if line.strip():
                            formatted_text += f"- {line}\n"
                    results.append(formatted_text)
                else:
                    results.append(f"📄 **Message:** {result_text}")
            if msg.video or msg.document:  # Media check karo
                # Forward media directly to the user
                await user.forward_messages(message.chat.id, CHANNEL_ID, msg.id)
                results.append("📁 **Media File Forwarded**")

        # Delete the searching message
        await search_msg.delete()

        if results:
            response = "**Search Results:**\n\n" + "\n\n".join(results)
            await message.reply_text(response, disable_web_page_preview=True)
        else:
            logger.info("No results found")
            await message.reply_text("❌ No results found!")
    except Exception as e:
        logger.error(f"Error during search: {e}")
        await message.reply_text("❌ An error occurred while searching. Please try again later.")
    finally:
        # Stop user session
        if user.is_connected:
            await user.stop()
            logger.info("User session stopped successfully.")

# Admin Commands
@bot.on_message(filters.command("admin") & filters.user(ADMIN_ID))
async def admin_panel(client, message):
    await message.reply_text("⚙️ Admin Commands:\n- /broadcast <message> (Send message to all users)")

# Broadcast Message (Only Admin)
@bot.on_message(filters.command("broadcast") & filters.user(ADMIN_ID))
async def broadcast(client, message):
    text = message.text.split(maxsplit=1)[1] if len(message.command) > 1 else None
    if text:
        async for user in bot.iter_dialogs():
            try:
                await bot.send_message(user.chat.id, text)
            except Exception as e:
                logger.error(f"Error sending broadcast to {user.chat.id}: {e}")
        await message.reply_text("✅ Broadcast sent!")
    else:
        await message.reply_text("❌ Please provide a message.")

# Run the bot
if __name__ == "__main__":
    logger.info("Starting bot...")
    bot.run()